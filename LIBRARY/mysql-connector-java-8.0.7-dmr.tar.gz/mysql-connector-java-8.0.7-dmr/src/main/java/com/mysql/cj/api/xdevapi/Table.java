/*
  Copyright (c) 2015, 2017, Oracle and/or its affiliates. All rights reserved.

  The MySQL Connector/J is licensed under the terms of the GPLv2
  <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>, like most MySQL Connectors.
  There are special exceptions to the terms and conditions of the GPLv2 as it is applied to
  this software, see the FOSS License Exception
  <http://www.mysql.com/about/legal/licensing/foss-exception.html>.

  This program is free software; you can redistribute it and/or modify it under the terms
  of the GNU General Public License as published by the Free Software Foundation; version 2
  of the License.

  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with this
  program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth
  Floor, Boston, MA 02110-1301  USA

 */

package com.mysql.cj.api.xdevapi;

import java.util.Map;

/**
 * A client-side representation of a database table. Provides access to the table through standard INSERT/SELECT/UPDATE/DELETE statements.
 */
public interface Table extends DatabaseObject {
    /**
     * Create an insert statement using the list of all columns in the table.
     * 
     * @return {@link InsertStatement}
     */
    InsertStatement insert();

    /**
     * Create an insert statement using the given list columns.
     * 
     * @param projection
     *            one or more projection expressions
     * @return {@link InsertStatement}
     */
    InsertStatement insert(String... projection);

    /**
     * Create an insert statement using the given key/value pairs.
     * 
     * @param fieldsAndValues
     *            table name-value pairs
     * @return {@link InsertStatement}
     */
    InsertStatement insert(Map<String, Object> fieldsAndValues);

    /**
     * Create a new select statement using the given projections.
     * 
     * @param projections
     *            one or more projection expressions
     * @return {@link SelectStatement}
     */
    SelectStatement select(String... projections);

    /**
     * Create a new update statement.
     * 
     * @return {@link UpdateStatement}
     */
    UpdateStatement update();

    /**
     * Create a new delete statement.
     * 
     * @return {@link DeleteStatement}
     */
    DeleteStatement delete();

    /**
     * Query the number of rows in this table.
     * 
     * @return Number of rows in this table
     */
    long count();

    /**
     * Check if the underlying object is a view or not.
     * 
     * @return true if this Table is a View
     */
    boolean isView();
}
